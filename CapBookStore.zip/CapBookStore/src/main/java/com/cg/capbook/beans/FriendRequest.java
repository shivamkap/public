package com.cg.capbook.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class FriendRequest {
	@Id
	private int friendRequestId;
	private int status;

	@ManyToOne(cascade=CascadeType.ALL)
	private Users user;

	public FriendRequest() {}

	public FriendRequest(int friendRequestId, int status, Users user) {
		super();
		this.friendRequestId = friendRequestId;
		this.status = status;
		this.user = user;
	}

	public int getFriendRequestId() {
		return friendRequestId;
	}

	public void setFriendRequestId(int friendRequestId) {
		this.friendRequestId = friendRequestId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + friendRequestId;
		result = prime * result + status;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FriendRequest other = (FriendRequest) obj;
		if (friendRequestId != other.friendRequestId)
			return false;
		if (status != other.status)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FriendRequest [friendRequestId=" + friendRequestId + ", status=" + status + ", user=" + user + "]";
	}
}
