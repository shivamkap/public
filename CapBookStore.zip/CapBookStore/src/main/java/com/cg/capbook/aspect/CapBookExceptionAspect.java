package com.cg.capbook.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;
import com.cg.capbook.exceptions.SecurityAnswerMismatchException;
import com.cg.capbook.exceptions.SecurityQuestionMismatchException;

@ControllerAdvice
public class CapBookExceptionAspect {
	@ExceptionHandler(UserDetailsNotFoundException.class)
	public ModelAndView handleCustomerDetailsNotFoundException(Exception e) {
		return new ModelAndView("indexPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(EmailAlreadyExistException.class)
	public ModelAndView handleEmailAlreadyExistException(Exception e) {
		return new ModelAndView("indexPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(PasswordMismatchException.class)
	public ModelAndView handlePasswordMismatchException(Exception e) {
		return new ModelAndView("indexPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(SecurityAnswerMismatchException.class)
	public ModelAndView handleSecurityAnswerMismatchException(Exception e) {
		return new ModelAndView("forgetPasswordPage","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(SecurityQuestionMismatchException.class)
	public ModelAndView handleSecurityQuestionMismatchException(Exception e) {
		return new ModelAndView("forgetPasswordPage","errorMessage",e.getMessage());
	}

}
