package com.cg.capbook.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Qualification {
	@Column(nullable=true)
	private String standard;
	@Column(nullable=true)
	private String institute;
	@Column(nullable=true)
	private String university;
	@Column(nullable=true)
	private float percentage;
	@Column(nullable=true)
	private Date passingYear;
	
	public Qualification() {}
	
	public Qualification(String standard, String institute, String university, float percentage, Date passingYear) {
		super();
		this.standard = standard;
		this.institute = institute;
		this.university = university;
		this.percentage = percentage;
		this.passingYear = passingYear;
	}
	
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getInstitute() {
		return institute;
	}
	public void setInstitute(String institute) {
		this.institute = institute;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public Date getPassingYear() {
		return passingYear;
	}
	public void setPassingYear(Date passingYear) {
		this.passingYear = passingYear;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((institute == null) ? 0 : institute.hashCode());
		result = prime * result + ((passingYear == null) ? 0 : passingYear.hashCode());
		result = prime * result + Float.floatToIntBits(percentage);
		result = prime * result + ((standard == null) ? 0 : standard.hashCode());
		result = prime * result + ((university == null) ? 0 : university.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Qualification other = (Qualification) obj;
		if (institute == null) {
			if (other.institute != null)
				return false;
		} else if (!institute.equals(other.institute))
			return false;
		if (passingYear == null) {
			if (other.passingYear != null)
				return false;
		} else if (!passingYear.equals(other.passingYear))
			return false;
		if (Float.floatToIntBits(percentage) != Float.floatToIntBits(other.percentage))
			return false;
		if (standard == null) {
			if (other.standard != null)
				return false;
		} else if (!standard.equals(other.standard))
			return false;
		if (university == null) {
			if (other.university != null)
				return false;
		} else if (!university.equals(other.university))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Qualification [standard=" + standard + ", institute=" + institute + ", university=" + university
				+ ", percentage=" + percentage + ", passingYear=" + passingYear + "]";
	}
}